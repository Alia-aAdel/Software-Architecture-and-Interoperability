const express = require("express");
const app = express();
const dotenv = require("dotenv");
const morgan = require("morgan");
dotenv.config({ path: "./config.env" });

const dbConnection = require("./config/database");

dbConnection();

const CategoryRoute = require("./routes/CategoryRoute");


app.use(express.json());
if(process.env.NODE_ENV === "development"){
    app.use(morgan("dev"));
    console.log(`Mode: ${process.env.NODE_ENV}`);
}


app.use("/api/v1/categories", CategoryRoute);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(` App Running on ${PORT}`);
});
